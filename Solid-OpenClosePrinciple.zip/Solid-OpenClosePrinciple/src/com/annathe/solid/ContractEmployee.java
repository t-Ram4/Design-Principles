package com.annathe.solid;

public class ContractEmployee extends Employee {

	public ContractEmployee(int id, String name, float salary) {
		super(id, name, salary);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float calculateBonus() {
		
		float bonus = salary * 0.2f;
		return bonus;
	}

}
