package com.annathe.solid;

public class PermanentEmployee extends Employee {

	public PermanentEmployee(int id, String name, float salary) {
		super(id, name, salary);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float calculateBonus() {
		
			float bonus = salary * 0.3f;
		
		
			return bonus;
	}
	
	
	

}
