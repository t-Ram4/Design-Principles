package com.annathe.solid;

public class Main {

	public static void main(String[] args) {
		
		
		
		Employee emp = new PermanentEmployee(100,"Yogesh",15000f);
		
		Employee emp1 = new ContractEmployee(100,"Kumar",20000f);
		
		System.out.println("Bonus: "+emp1.calculateBonus());
		
		
		// TODO Auto-generated method stub

	}

}
