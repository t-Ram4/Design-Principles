package com.annathe.solid;

public interface Database {
	
	public void connect();
	
	public void disconnect();

}
