package com.annathe.solid;

public class OracleDatabase implements Database {

	public void connect() {
		System.out.println("connected to Oracle Database");
	}

	public void disconnect() {
		System.out.println("Disconnected from Oracle Database");

	}

}
