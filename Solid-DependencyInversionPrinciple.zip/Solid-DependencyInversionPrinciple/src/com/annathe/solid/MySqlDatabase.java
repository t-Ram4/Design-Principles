package com.annathe.solid;

public class MySqlDatabase implements Database {

	public void connect() {
		System.out.println("connected to MySql Database");
	}

	public void disconnect() {
		System.out.println("disconnected from MySql Database");

	}

}
