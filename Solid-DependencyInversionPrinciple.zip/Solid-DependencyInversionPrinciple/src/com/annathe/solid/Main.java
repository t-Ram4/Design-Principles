package com.annathe.solid;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	DatabaseHandler databaseHandler = new DatabaseHandler(new OracleDatabase());
	
	
	databaseHandler.connect();
	
	databaseHandler.disconnect();
	
	}

}
