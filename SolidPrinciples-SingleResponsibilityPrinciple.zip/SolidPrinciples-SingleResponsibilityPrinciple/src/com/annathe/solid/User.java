package com.annathe.solid;

public class User  implements Iuser{

	
	public boolean login(String userId, String password) {
		// it hs code for authentication
		return false;
	}

	
	public boolean register(String userId, String password, String email) {
		// code for saving registration details into database
		return false;
	}


	




}
