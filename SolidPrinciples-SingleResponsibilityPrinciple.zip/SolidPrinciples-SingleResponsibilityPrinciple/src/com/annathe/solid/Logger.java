package com.annathe.solid;

public class Logger implements ILogger {

	@Override
	public void logError(String error) {
		// TODO Auto-generated method stub

	}

}
