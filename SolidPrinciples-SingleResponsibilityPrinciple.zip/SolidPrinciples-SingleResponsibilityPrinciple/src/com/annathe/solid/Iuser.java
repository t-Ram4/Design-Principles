package com.annathe.solid;

public interface Iuser {
	
	public boolean login(String userId,String password);
	
	public boolean register(String userId, String password, String email);

}
