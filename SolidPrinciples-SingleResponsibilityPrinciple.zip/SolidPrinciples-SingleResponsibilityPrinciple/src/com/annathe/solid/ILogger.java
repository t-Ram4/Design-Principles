package com.annathe.solid;

public interface ILogger {
	
	public void logError(String error);

}
