package com.annathe.solid;

public interface IEmail {
	
	public boolean sendEmail(String emailContent);

}
