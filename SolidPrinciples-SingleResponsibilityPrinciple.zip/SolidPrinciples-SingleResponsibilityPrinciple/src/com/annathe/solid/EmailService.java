package com.annathe.solid;

public class EmailService implements IEmail {

	@Override
	public boolean sendEmail(String emailContent) {
		// TODO Auto-generated method stub
		return false;
	}

}
