package com.annathe.solid;

public interface IScan {
	
	public boolean scanContent(String content);
}
