package com.annathe.solid;

public interface IPrinterTasks {
	
	public boolean printContent(String content);
	
	public boolean scanContent(String content);
	
	public boolean faxContent(String content);
	
	public boolean photoCopyContent(String content);
	
	
	
	
	

}
