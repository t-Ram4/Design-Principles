package com.annathe.solid;

public interface IPhotocopy {
	
	public boolean photoCopyContent(String content);
	

}
