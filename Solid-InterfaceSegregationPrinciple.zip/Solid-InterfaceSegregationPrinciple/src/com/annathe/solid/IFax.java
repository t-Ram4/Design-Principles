package com.annathe.solid;

public interface IFax {
	public boolean faxContent(String content);

}
