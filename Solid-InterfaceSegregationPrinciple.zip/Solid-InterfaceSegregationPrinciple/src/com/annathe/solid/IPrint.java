package com.annathe.solid;

public interface IPrint {
	
	public boolean printContent(String content);

}
