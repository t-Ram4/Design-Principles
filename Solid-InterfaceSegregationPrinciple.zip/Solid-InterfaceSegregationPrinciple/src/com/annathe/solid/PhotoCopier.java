package com.annathe.solid;

public class PhotoCopier implements IPhotocopy {

	
	

	@Override
	public boolean photoCopyContent(String content) {
		
		System.out.println("Completed photocopying");
		return true;
	}

}
