package com.annathe.solid;

public class MultiPrinter implements IPrint,IPhotocopy,IScan,IFax {

	@Override
	public boolean printContent(String content) {
		System.out.println("Completed printing");
		return true;
	}

	@Override
	public boolean scanContent(String content) {
		System.out.println("Completed scanning");
		return true;
	}

	@Override
	public boolean faxContent(String content) {
		System.out.println("Completed faxing");
		return true;
	}

	@Override
	public boolean photoCopyContent(String content) {
		System.out.println("Completed photocopying");
		return true;
	}

}
