package com.annathe.solid;

import java.util.Date;

public abstract class Member {
	
	private String name;
	
	private Date startDate;
	
	private Date endDate;
	
	public abstract void makeBooking();
	
	public abstract void addToDatabase();

}
