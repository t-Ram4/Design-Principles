package com.annathe.solid;

public class LifeTimeMember extends Member {

	@Override
	public void makeBooking() {
		System.out.println("Booking made for LifeTime member");

	}

	@Override
	public void addToDatabase() {
		System.out.println("added to database for LifeTime member");
	}


}
