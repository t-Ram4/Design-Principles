package com.annathe.solid;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		
		Member annualMember =  new AnnualMember();
		
		Member lifetimeMember =  new LifeTimeMember();
		
		List<Member> members = new ArrayList<Member>();
		
		members.add(annualMember);
		members.add(lifetimeMember);
		
		for(Member m : members) {
			
			m.addToDatabase();
			m.makeBooking();
		}
	}

}
