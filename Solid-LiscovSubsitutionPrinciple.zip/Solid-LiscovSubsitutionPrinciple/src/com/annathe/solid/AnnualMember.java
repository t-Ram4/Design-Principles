package com.annathe.solid;

public class AnnualMember extends Member {

	@Override
	public void makeBooking() {
		System.out.println("Booking made for Annual member");

	}

	@Override
	public void addToDatabase() {
		System.out.println("added to database for Annual member");
	}

}
